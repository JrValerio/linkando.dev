
const page = () => {
  return (
    <div>Register</div>
  )
}

export default page